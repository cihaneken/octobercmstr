<?php include 'install_files/php/boot.php'; ?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <title>October Installation</title>
        <link type="image/png" href="install_files/images/october.png" rel="icon">

        <!-- Styles -->
        <link href="install_files/css/vendor.css" rel="stylesheet">
        <link href="install_files/css/layout.css" rel="stylesheet">
        <link href="install_files/css/controls.css" rel="stylesheet">
        <link href="install_files/css/animations.css" rel="stylesheet">
        <link href="install_files/css/fonts.css" rel="stylesheet">

        <!-- Base URL -->
        <?php if (!isset($fatalError)): ?>
            <script>
            <!--
                installerBaseUrl = '<?= $installer->getBaseUrl() ?>';
            // -->
            </script>
        <?php endif ?>
    </head>
    <body class="js">

        <div id="wrap">

            <!-- Header -->
            <header>
                <div class="container" id="containerHeader"></div>

                <!-- Title -->
                <section class="title">
                    <div class="container" id="containerTitle"></div>
                </section>

            </header>

            <!-- Body -->
            <section class="body">
                <?php if (isset($fatalError)): ?>
                    <div class="container">
                        <div class="callout callout-danger"><?= $fatalError ?></div>
                    </div>
                <?php else: ?>
                    <div class="container" id="containerBody"></div>
                <?php endif ?>
            </section>

        </div>

        <!-- Footer -->
        <footer>
            <div class="container" id="containerFooter"></div>
        </footer>

        <?php if (!isset($fatalError)): ?>

            <!-- Render Partials -->
            <?php
                $partialList = [
                    'header',
                    'title',
                    'footer',
                    'check',
                    'check/fail',
                    'config',
                    'config/mysql',
                    'config/pgsql',
                    'config/sqlite',
                    'config/sqlsrv',
                    'config/fail',
                    'config/database',
                    'config/admin',
                    'config/advanced',
                    'starter',
                    'themes',
                    'themes/theme',
                    'project',
                    'project/project',
                    'project/plugins',
                    'project/plugin',
                    'project/themes',
                    'project/theme',
                    'project/suggestion',
                    'project/fail',
                    'progress',
                    'progress/fail',
                    'complete'
                ];
            ?>

            <?php foreach ($partialList as $file): ?>
                <script type="text/template" data-partial="<?= $file ?>">
                    <?php include 'install_files/partials/'.$file.'.htm'; ?>
                </script>
            <?php endforeach ?>

            <!-- Scripts -->
            <script src="install_files/js/vendor.js"></script>
            <script src="install_files/js/app.js"></script>
            <script src="install_files/js/check.js"></script>
            <script src="install_files/js/config.js"></script>
            <script src="install_files/js/starter.js"></script>
            <script src="install_files/js/themes.js"></script>
            <script src="install_files/js/project.js"></script>
            <script src="install_files/js/progress.js"></script>
            <script src="install_files/js/complete.js"></script>

            <!-- Bespoke Properties -->
            <script>
                /*
                 * Checker Page
                 */
                Installer.Pages.systemCheck.title = 'Sistem Kontrolü'
                Installer.Pages.systemCheck.nextButton = 'Kabul ve Devam'

                Installer.Pages.systemCheck.requirements = [
                    { code: 'phpVersion', label: 'PHP sürüm 7.0 veya üstü gerekiyor' },
                    { code: 'curlLibrary', label: 'cURL PHP Uzantısı gerekiyor' },
                    { code: 'liveConnection', label: 'Kurulum sunucusuna bağlantıyı test etme' },
                    { code: 'writePermission', label: 'Dizinlere ve dosyalara yazma izni', reason: 'Yükleyici yükleme dizin ve dosyalarına yazamadı.' },
                    { code: 'pdoLibrary', label: 'PDO PHP Uzantısı gerekiyor' },
                    { code: 'mbstringLibrary', label: 'Mbstring PHP Uzantısı gerekiyor' },
                    { code: 'fileinfoLibrary', label: 'Fileinfo PHP Uzantısı gerekiyor' },
                    { code: 'sslLibrary', label: 'OpenSSL PHP Uzantısı gerekiyor' },
                    { code: 'zipLibrary', label: 'ZipArchive PHP Kütüphanesi gerekiyor' },
                    { code: 'gdLibrary', label: 'GD PHP Kütüphanesi gerekiyor' }
                ]

                /*
                 * Config Page
                 */
                Installer.Pages.configForm.title = 'Yapılandırma'
                Installer.Pages.configForm.nextButton = 'Devam et'

                Installer.Pages.configForm.sections = [
                    { code: 'database', label: 'Veritabanı', category: 'Genel', handler: 'onValidateDatabase', partial: 'config/database' },
                    { code: 'admin', label: 'Yönetici', category: 'Genel', handler: 'onValidateAdminAccount', partial: 'config/admin' },
                    { code: 'advanced', label: 'Gelişmiş', category: 'Gelişmiş', handler: 'onValidateAdvancedConfig', partial: 'config/advanced' }
                ]

                /*
                 * Starter Page
                 */
                Installer.Pages.starterForm.title = 'Başlarken'

                /*
                 * Themes Page
                 */
                Installer.Pages.themesForm.title = 'Bir temadan başla'

                /*
                 * Project Page
                 */
                Installer.Pages.projectForm.title = 'Proje detayları'
                Installer.Pages.projectForm.nextButton = 'Kurulumu Yap!'

                Installer.Pages.projectForm.sections = [
                    { code: 'project', label: 'Proje', partial: 'project/project' },
                    { code: 'plugins', label: 'Eklentiler', partial: 'project/plugins' },
                    { code: 'themes', label: 'Temalar', partial: 'project/themes' }
                ]

                /*
                 * Progress Page
                 */
                Installer.Pages.installProgress.title = 'Kurulum ilerleme durumu...'
                Installer.Pages.installProgress.steps = [
                    { code: 'getMetaData', label: 'Paket bilgileri isteniyor' },
                    { code: 'downloadCore', label: 'Uygulama dosyaları yükleniyor' },
                    { code: 'downloadPlugins', label: 'Eklenti indiriliyor: ' },
                    { code: 'downloadThemes', label: 'Tema indiriliyor: ' },
                    { code: 'extractCore', label: 'Uygulama dosyalarının paketinden çıkarılması' },
                    { code: 'extractPlugins', label: 'Paketi açma eklentisi: ' },
                    { code: 'extractThemes', label: 'Paketi açma eklentisi: ' },
                    { code: 'setupConfig', label: 'Yapılandırma dosyalarını oluşturma' },
                    { code: 'createAdmin', label: 'Yönetici hesabı oluştur' },
                    { code: 'setupProject', label: 'Web sitesi projesini ayarlama' },
                    { code: 'finishInstall', label: 'Kurulum sonlandırılıyor' }
                ]

                /*
                 * Final Pages
                 */
                Installer.Pages.installComplete.title = 'Tebrik ederiz!'

            </script>

        <?php endif ?>

    </body>
</html>
